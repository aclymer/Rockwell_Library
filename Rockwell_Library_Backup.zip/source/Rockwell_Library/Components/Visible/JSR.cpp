#include "Stdafx.h"
#include "Rockwell_Library/Components/Visible/JSR.h"

namespace Rockwell_Library
{
	System::Void JSR::Execute(double p_dTimeStep)
	{
	}
}