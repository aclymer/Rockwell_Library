#include "Stdafx.h"
#include "Rockwell_Library/Components/Visible/MOV.h"
#define __MAXWORDS__ 128

using namespace IPS;

namespace Rockwell_Library
{
	void MOV::Execute(double p_dTimeStep)
	{
		System::Double^ value = gcnew double;
		bool constant = System::Double::TryParse(Source.Value, *value);

		if (Source.Value->StartsWith("#"))
			Source.Value = Source.Value->Remove(0,1);
		if (Dest.Value->StartsWith("#"))
			Dest.Value = Dest.Value->Remove(0,1);

		if (!constant)
		{
			ParseAddress(source_parsed, Source.Value);
			m_SourceComponent	= this->m_Project->GetComponent(Source.Value);
		}

		if (Trigger.Value)
		{
			if (constant)
				MOV::Set_Property(Dest.Value, dynamic_cast<System::Object^>(value));

			else 
			{
				ParseAddress(dest_parsed, Dest.Value);

				if (dest_parsed[1] == "ST")
					this->m_Project->GetComponent(Dest.Value)->UserDescription->Value = m_SourceComponent->UserDescription->Value;

				else if (dest_parsed[1] != "C")
					MOV::Set_Property(Dest.Value, MOV::Get_Property(Source.Value));	
			}
		}
	}
}
