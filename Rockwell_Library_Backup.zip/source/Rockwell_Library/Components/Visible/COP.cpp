#include "Stdafx.h"
#include "Rockwell_Library/Components/Visible/COP.h"
#define __MAXWORDS__ 128

using namespace IPS;

namespace Rockwell_Library
{
	void COP::Execute(double p_dTimeStep)
	{
		if (Source.Value->StartsWith("#"))
			Source.Value = Source.Value->Remove(0,1);
		if (Dest.Value->StartsWith("#"))
			Dest.Value = Dest.Value->Remove(0,1);

		if (Trigger.Value)
		{
			ParseAddress(source_parsed, Source.Value);
			ParseAddress(dest_parsed, Dest.Value);

			if (dest_parsed[1] == "ST")
				this->m_Project->GetComponent(Dest.Value)->UserDescription->Value = this->m_Project->GetComponent(Source.Value)->UserDescription->Value;
			
			else if (dest_parsed[1] != "C")
			{
				Int16 start, end;
				Int16::TryParse(source_parsed[3], start);
				Int16::TryParse(dest_parsed[3], end);
				String^ source_string;
				String^ dest_string;
				for (int i = 0; i < Length.Value; i++)
				{
					source_string	= source_parsed[1] + source_parsed[2] + ":" + (start + i).ToString() + source_parsed[4] + (source_parsed.Count < 6 ? "" : source_parsed[5]);
					dest_string		= dest_parsed[1]   + dest_parsed[2]   + ":" + (end + i).ToString() + dest_parsed[4] + (dest_parsed.Count < 6 ? "" : dest_parsed[5]);

					COP::Set_Property(dest_string, COP::Get_Property(source_string));
				}
			}
		}
	}
}
