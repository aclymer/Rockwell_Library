#include "stdafx.h"
#include "Rockwell_Library/Components/Visible/LBL.h"

namespace Rockwell_Library
{
	void LBL::Execute(double p_dTimeStep)
	{
		Output.Value = true;
	}
}