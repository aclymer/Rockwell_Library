#include "stdafx.h"
#include "Rockwell_Library/Components/Visible/XIO.h"

namespace Rockwell_Library
{
	void XIO::Execute(double p_dTimeStep)
	{
		Output.Value = false;
		Value.ValueAsObject = XIO::Get_Property(Property.Value);

		if (Value.Value == false)
			Output.Value = Input.Value;
	}
}