#include "stdafx.h"
#include "Rockwell_Library/Components/Visible/OTU.h"

namespace Rockwell_Library
{
	void OTU::Execute(double p_dTimeStep)
	{
		if (Input.Value == true)
		{
			Output.Value = false;
			OTU::Set_Property(Property.Value, Output.ValueAsObject);
		}

		Output.Value = Input.Value;
	}
}