#include "stdafx.h"
#include "Rockwell_Library/Components/Visible/GRT.h"

namespace Rockwell_Library
{
	void GRT::Execute(double p_dTimeStep)
	{
		Value_A.ValueAsObject = GRT::Get_Property(Source_A.Value);
		Value_B.ValueAsObject = GRT::Get_Property(Source_B.Value);

		if (Value_A.Value > Value_B.Value)
			Output.Value = Input.Value;
	}
}