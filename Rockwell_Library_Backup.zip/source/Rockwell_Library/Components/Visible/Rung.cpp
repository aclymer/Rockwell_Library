#include "stdafx.h"
#include "Rockwell_Library/Components/Visible/Rung.h"


namespace Rockwell_Library
{
	System::Void Rung::Execute(double p_dTimeStep)
	{
	}

}