#include "stdafx.h"
#include "Rockwell_Library/Components/Visible/XIC.h"

namespace Rockwell_Library
{
	void XIC::Execute(double p_dTimeStep)
	{
		Output.Value = false;
		Value.ValueAsObject = XIC::Get_Property(Property.Value);

		if (Value.Value == true)
			Output.Value = Input.Value;
	}
}