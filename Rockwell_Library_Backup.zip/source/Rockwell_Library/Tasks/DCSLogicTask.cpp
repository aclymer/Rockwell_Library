#include "Stdafx.h"
#include "Rockwell_Library/Tasks/DCSLogicTask.h"
#include "Rockwell_Library/Components/Hidden/DCSLogicComponent.h"

namespace Rockwell_Library {
	
	System::Void DCSLogicTask::InitProperties()
	{
		IPS::Task::TaskBase::InitProperties();
	}//InitProperties
	
	System::Void DCSLogicTask::Load(IPS::Core::Project^  project)
	{
		TaskBase::Load(project);
		m_pProject = project;
		LoadEvents();
		Activate();
		InitialiseVisibilities();
		if (Instance == nullptr)
		{
			Instance = this;
		}
		for each (IPS::Core::DrawingPage^ l_Page in project->Pages)
		{
			if (l_Page->UserDescription->Value->StartsWith("Ladder"))
				if (dynamic_cast<IPS::Core::DrawingPage^>(l_Page) != nullptr)
					LadderPageDictionary.Add(l_Page->UserDescription->Value->Remove(0,7), l_Page);
		}
		SetPageInclude("U:2");
		
		//ControlTask().DiagnosticMode.Value = true;
	}
	
	System::Void DCSLogicTask::Unload()
	{
		TaskBase::Unload();
		UnloadEvents();
	}

	void DCSLogicTask::SetPageInclude(String^ ladderPageID)
	{
		try
		{
			for each (KeyValuePair<String^, IPS::Core::DrawingPage^>^ keyValuePair in LadderPageDictionary)
			{
				if (keyValuePair->Key == ladderPageID)
					;// Do something
				else
				{
					keyValuePair->Value;
				}
			}
		}
		catch (Exception^ ex)
		{
			IPS::Errors::ErrorSystem::Report(gcnew IPS::Errors::ElementError("lalala", this->Identifier, "Unknown exception occured during DCSLogicTask::InitialiseVisibilities function call : " + ex->Message));
		}
	}

	void DCSLogicTask::InitialiseVisibilities()
	{
		try
		{
			for each (DCSLogicComponent^ l_DCSLogicComponent in m_DCSLogicComponents)
			{
				l_DCSLogicComponent->InitialiseVisibilities();
			}
		}
		catch (Exception^ ex)
		{
			IPS::Errors::ErrorSystem::Report(gcnew IPS::Errors::ElementError("lalala", this->Identifier, "Unknown exception occured during DCSLogicTask::InitialiseVisibilities function call : " + ex->Message));
		}
	}

	System::Void DCSLogicTask::LoadEvents()
	{
		m_pActivateEventHandler = gcnew IPS::Core::EventFunction(this, &DCSLogicTask::Activate);
		Project->Events->AddActivateEvent(this, m_pActivateEventHandler);
		m_pDeactivateEventHandler = gcnew IPS::Core::EventFunction(this, &DCSLogicTask::Deactivate);
		Project->Events->AddDeactivateEvent(this, m_pDeactivateEventHandler);
		m_pStepEventHandler = gcnew IPS::Core::EventFunction(this, &DCSLogicTask::Step);
		Project->Events->AddStepEvent(this, m_pStepEventHandler);
	}//LoadEvents
	
	System::Void DCSLogicTask::UnloadEvents()
	{
		Project->Events->RemoveActivateEvent(this);
		delete m_pActivateEventHandler;;
		Project->Events->RemoveDeactivateEvent(this);
		delete m_pDeactivateEventHandler;;
		Project->Events->RemoveStepEvent(this);
		delete m_pStepEventHandler;;
	}//UnloadEvents

	System::Void DCSLogicTask::Activate(System::Void )
	{
		try
		{
			m_DCSLogicComponents.Clear();
			this->FilterComponents(DCSLogicComponent::typeid, m_DCSLogicComponents);
			for each (DCSLogicComponent^ m_lComponent in m_DCSLogicComponents)
			{
				try
				{
					m_lComponent->Activate_Compound();
				}
				catch (Exception^ ex)
				{
					IPS::Errors::ErrorSystem::Report(gcnew IPS::Errors::ElementError("blabla", m_lComponent->Identifier, "Unknown exception occured during DCSLogicTask::Activate event : " + ex->Message));
				}
			}
		}
		catch (Exception^ ex)
		{
			IPS::Errors::ErrorSystem::Report(gcnew IPS::Errors::ElementError("blabla", this->Identifier, "Unknown exception occured during DCSLogicTask::Activate event : " + ex->Message));
		}
	}//Activate

	System::Void DCSLogicTask::Deactivate(System::Void )
	{
		try
		{
		}
		catch (Exception^ ex)
		{
			IPS::Errors::ErrorSystem::Report(gcnew IPS::Errors::ElementError("blabla", this->Identifier, "Unknown exception occured during DCSLogicTask::Deactivate event : " + ex->Message));
		}
	}//Deactivate

	System::Void DCSLogicTask::Step(System::Void)
	{
		try
		{
			for each (DCSLogicComponent^ l_DCSLogicComponent in m_DCSLogicComponents)
			{
				// Done in DCS task
			}			
		}
		catch (Exception^ ex)
		{
			IPS::Errors::ErrorSystem::Report(gcnew IPS::Errors::ElementError("blabla", this->Identifier, "Unknown exception occured during DCSLogicTask::Step event : " + ex->Message));
		}
	}//Step
	

}
