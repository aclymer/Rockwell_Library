#include "stdafx.h"
#include "Rockwell_Library/Tasks/DCSLogicTaskDrawingTextProvider.h"
#include "Rockwell_Library/Components/Hidden/DCSLogicComponent.h"

using namespace System;
using namespace System::Windows::Forms;
using namespace System::Threading;

namespace Rockwell_Library {

	DCSLogicTaskDrawingTextProvider::DCSLogicTaskDrawingTextProvider()
	{
	}

	void DCSLogicTaskDrawingTextProvider::GetDrawingText(Object^ objectToProvideMenuFor, System::Collections::Generic::List<IPS::Plugin::DrawingText>^ returnDrawingTexts)
	{
		DCSLogicComponent^ l_pDCSLogicComponent = dynamic_cast<DCSLogicComponent^>(objectToProvideMenuFor);
		if (l_pDCSLogicComponent->Name == "Rung")
		{
			IPS::Plugin::DrawingText l_ComponentDrawingText_Description;
			l_ComponentDrawingText_Description.Location = IPS::Plugin::TextLocation::Center;
			l_ComponentDrawingText_Description.Text = (l_pDCSLogicComponent->Identifier->ToString()->StartsWith("Rung") ? l_pDCSLogicComponent->Identifier->ToString()->Remove(0,5) : l_pDCSLogicComponent->Identifier->ToString());
			returnDrawingTexts->Add( l_ComponentDrawingText_Description );
		}
	}

}