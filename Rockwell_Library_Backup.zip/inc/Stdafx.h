// Stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once
#include "stdafx.h"

#using "../../IPS.Core.dll"
#using "../../IPS.PluginInterface.dll"
#using "../../IPS.Component.dll"
#using "../../IPS.Task.dll"
#using "../../IPS.Scheduler.dll"
#using "../../IPS.Actions.dll"
#using "../../IPS.Collections.dll"
#using "../../IPS.DataReference.dll"
#using "../../IPS.DefaultEditor.dll"
#using "../../IPS.Errors.dll"
#using "../../IPS.EventManager.dll"
#using "../../IPS.Help.dll"
#using "../../IPS.LibraryInterfaces.dll"
#using "../../IPS.LibraryProvider.dll"
#using "../../IPS.Persistence.dll"
#using "../../IPS.Project.DocViewFramework.dll"
#using "../../IPS.Properties.dll"
#using "../../IPS.PropertyBrowsing.dll"
#using "../../IPS.Remoting.dll"
#using "../../IPS.Styles.dll"
#using "../../IPS.TaskThreading.dll"
#using "../../IPS.Units.dll"
#using "../../IPS.VersionControl.dll"
#using "../../IPS.Visualisation.dll"
#using "../../SmartPropertyGrid.dll"
#using "../../ZedGraph.dll"
