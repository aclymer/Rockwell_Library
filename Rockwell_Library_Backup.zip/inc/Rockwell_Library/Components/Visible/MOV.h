#pragma once
#include "Ports.h"
#include "Rockwell_Library/Components/Hidden/DCSLogicComponent.h"
#include "Rockwell_Library/Tasks/DCSLogicTask.h"

using namespace System;
using namespace DCS::Ports;

namespace Rockwell_Library
{    
	[IPS::Plugin::LibraryInfo("MOV", IPS::Plugin::Visibility::VISIBLE, "Property Copy")]
	[IPS::Plugin::LibraryImage("MOV.png")]
	[IPS::Plugin::LibrarySizeAttribute(200,150)]
	[IPS::Plugin::LibraryRelativeSizeAttribute(false)]
	[IPS::Plugin::LibraryCategory("Ladder Logic", "Move and Logical Instructions")]
	[IPS::Plugin::Port("InputPort",	 Bool::BoolInputPort::typeid, -1,  0, -1,   0, 20, 13, 20, "Green", true, "")]
	[IPS::Plugin::Port("OutputPort", Bool::BoolOutputPort::typeid, 0, -1, -1, 100, 20, 13, 20, "Green", true, "")]
	
	public ref class MOV : public DCSLogicComponent
	{	
		public:

			Rockwell_Library::MOV()
			{
				TypeDescription			= "MOV";
				Name					= "MOV";
				Descriptor				= "Move Word";

				Trigger.Visible			= true;
				InputPort				= dynamic_cast<Bool::BoolInputPort^>(PortByName("InputPort"));
				InputPort->SetAssociatedProperty(%m_Trigger);

				Dest_Value.Visible		= true;
				Source.Visible			= true;
				Dest.Visible			= true;	
			
				m_Project = IPS::Server::IProject::GetInstance();
			}

			[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
			[IPS::Properties::DisplayName("Trigger")]
			[IPS::Properties::GridOrder(10)]
			[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Inputs"})]
			virtual property IPS::Properties::Bool%  Trigger
			{
				IPS::Properties::Bool%  get()
				{
					return m_Trigger;
				}
			}
		
			[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
			[IPS::Properties::DisplayName("Source Identifier")]
			[IPS::Properties::GridOrder(10)]
			[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Components"})]
			virtual property IPS::Properties::Text%  Source
			{
				IPS::Properties::Text%  get()
				{
					return m_Source;
				}
			}
		
			[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
			[IPS::Properties::DisplayName("Value")]
			[IPS::Properties::GridOrder(35)]
			[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Components"})]
			virtual property IPS::Properties::DataReferenceProperty%  Source_Value
			{
				IPS::Properties::DataReferenceProperty%  get()
				{
					return m_Source_Value;
				}
			}
		
			[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
			[IPS::Properties::DisplayName("Dest Identifier")]
			[IPS::Properties::GridOrder(25)]
			[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Components"})]
			virtual property IPS::Properties::Text%  Dest
			{
				IPS::Properties::Text%  get()
				{
					return m_Dest;
				}
			}
		
			[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
			[IPS::Properties::DisplayName("Value")]
			[IPS::Properties::GridOrder(35)]
			[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Components"})]
			virtual property IPS::Properties::DataReferenceProperty%  Dest_Value
			{
				IPS::Properties::DataReferenceProperty%  get()
				{
					return m_Dest_Value;
				}
			}
		
		public:

			virtual System::Void InitProperties() override
			{
				IPS::Plugin::ComponentBase::InitProperties();
			}
			
			virtual System::Void Execute(double) override;
		
			virtual void SetVisibilities(bool l_bShowInvisibleProperties) override
			{
				DCSLogicComponent::SetVisibilities(l_bShowInvisibleProperties);

				if (l_bShowInvisibleProperties == true)
				{
					Trigger.Visible				= true;
					Dest_Value.Visible		= true;
					Source.Visible				= true;
					Dest.Visible				= true;
				}
				else
				{
					Trigger.Visible				= m_Trigger.Visible;
					Dest_Value.Visible		= m_Dest_Value.Visible;
					Source.Visible				= m_Source.Visible;
					Dest.Visible				= m_Dest.Visible;
				}
			}
	
		private:
		      
			IPS::Properties::DataReferenceProperty	m_Source_Value; 
			IPS::Properties::DataReferenceProperty	m_Dest_Value;  
			IPS::Properties::Bool					m_Trigger;                  
			IPS::Properties::Text					m_Source;        
			IPS::Properties::Text					m_Dest;
			List<String^>							source_parsed;
			List<String^>							dest_parsed;
			IPS::Core::Component^					m_SourceComponent;
			IPS::Core::Component^					m_DestComponent;
			IPS::Core::Property^					m_TransferProperty;

		protected:

			DCSInputPortBase^						InputPort;
			DCSOutputPortBase^						OutputPort;
	};    
}
