#pragma once
#include "Ports.h"
#include "Rockwell_Library/Components/Hidden/DCSLogicComponent.h"
#include "Rockwell_Library/Tasks/DCSLogicTask.h"

using namespace System;
using namespace IPS::Server;
using namespace DCS::Ports;

namespace Rockwell_Library
{
	[IPS::Plugin::LibraryInfo("EQU", IPS::Plugin::Visibility::VISIBLE, "Equal")]
	[IPS::Plugin::LibraryImage("EQU.png")]
	[IPS::Plugin::LibrarySizeAttribute(200,125)]
	[IPS::Plugin::LibraryRelativeSizeAttribute(false)]
	[IPS::Plugin::LibraryCategory("Ladder Logic", "Comparison Instructions")]
	[IPS::Plugin::Port("InputPort", Bool::BoolInputPort::typeid, -1, 0, -1, 0, 19, 13, 19, "Green", true, "")]
	[IPS::Plugin::Port("OutputPort", Bool::BoolOutputPort::typeid, 0, -1, -1, 88, 19, 13, 19, "Green", true, "")]
	
	public ref class EQU : public DCSLogicComponent
	{
	public:
		
		Rockwell_Library::EQU()
		{
			TypeDescription			= "EQU";
			Name					= "EQU";
			Descriptor				= "Equal";

			Input.Visible			= true;
			Input.Value				= false;
			InputPort				= dynamic_cast<Bool::BoolInputPort^>(PortByName("InputPort"));
			InputPort->SetAssociatedProperty(%m_Input);
			
			Output.Visible			= true;
			Output.Value			= false;
			OutputPort				= dynamic_cast<Bool::BoolOutputPort^>(PortByName("OutputPort"));
			OutputPort->SetAssociatedProperty(%m_Output);

			Source_A.Visible		= true;
			Source_A.Value			= "Address";

			Value_A.Visible			= true;
			Value_A.Value			= 0;
			
			Source_B.Visible		= true;
			Source_B.Value			= "Address";

			Value_B.Visible			= true;
			Value_B.Value			= 0;

			m_Project				= IPS::Server::IProject::GetInstance();
		}

		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Input")]
		[IPS::Properties::GridOrder(0)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"General"})]
		virtual property IPS::Properties::Bool%  Input
		{
			IPS::Properties::Bool%  get()
			{
				return m_Input;
			}
		}
		
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Output")]
		[IPS::Properties::GridOrder(1)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"General"})]
		virtual property IPS::Properties::Bool%  Output
		{
			IPS::Properties::Bool%  get()
			{
				return m_Output;
			}
		}
		
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Source A")]
		[IPS::Properties::GridOrder(100)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Components"})]
		virtual property IPS::Properties::Text%  Source_A
		{
			IPS::Properties::Text%  get()
			{
				return m_Source_A;
			}
		}
		
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Value")]
		[IPS::Properties::GridOrder(110)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Components"})]
		virtual property IPS::Properties::Double%  Value_A
		{
			IPS::Properties::Double%  get()
			{
				return m_Value_A;
			}
		}
		
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Source B")]
		[IPS::Properties::GridOrder(120)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Components"})]
		virtual property IPS::Properties::Text%  Source_B
		{
			IPS::Properties::Text%  get()
			{
				return m_Source_B;
			}
		}
		
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Value")]
		[IPS::Properties::GridOrder(130)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Components"})]
		virtual property IPS::Properties::Double%  Value_B
		{
			IPS::Properties::Double%  get()
			{
				return m_Value_B;
			}
		}
		
		//
		// Methods
		//

		virtual System::Void InitProperties() override
		{
			IPS::Plugin::ComponentBase::InitProperties();
		}
		
		virtual System::Void Execute(double) override;
		
		virtual void SetVisibilities(bool l_bShowInvisibleProperties) override
		{
			DCSLogicComponent::SetVisibilities(l_bShowInvisibleProperties);

			if (l_bShowInvisibleProperties == true)
			{
				Input.Visible				= true;
				Output.Visible				= true;
				Source_A.Visible			= true;
				Source_B.Visible			= true;
				Value_A.Visible				= true;
				Value_B.Visible				= true;
			}
			else
			{
				Input.Visible				= m_Input.Visible;
				Output.Visible				= m_Output.Visible;
				Source_A.Visible			= m_Source_A.Visible;
				Source_B.Visible			= m_Source_B.Visible;
				Value_A.Visible				= m_Value_A.Visible;
				Value_B.Visible				= m_Value_B.Visible;
			}
		}

	private: 
			
			IPS::Properties::Bool	m_Input;
			IPS::Properties::Bool	m_Output;
			IPS::Properties::Text	m_Source_A;
			IPS::Properties::Text	m_Source_B;
			IPS::Properties::Double	m_Value_A;
			IPS::Properties::Double	m_Value_B;
			DCSInputPortBase^		InputPort;
			DCSOutputPortBase^		OutputPort;
	};
}