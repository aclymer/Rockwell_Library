#pragma once
#include "Ports.h"
#include "Rockwell_Library/Components/Hidden/DCSLogicComponent.h"
#include "Rockwell_Library/Tasks/DCSLogicTask.h"

using namespace System;
using namespace IPS::Server;
using namespace DCS::Ports;

namespace Rockwell_Library
{
	[IPS::Plugin::LibraryInfo("OTE", IPS::Plugin::Visibility::VISIBLE, "Output Energize")]
	[IPS::Plugin::LibraryImage("OTE.png")]
	[IPS::Plugin::LibrarySizeAttribute(50,50)]
	[IPS::Plugin::LibraryRelativeSizeAttribute(false)]
	[IPS::Plugin::LibraryCategory("Ladder Logic", "Relay Type Instructions")]
	[IPS::Plugin::Port("InputPort", Bool::BoolInputPort::typeid, -1, 0, -1, 0, 50, 25, 100, "Green", true, "")]
	[IPS::Plugin::Port("OutputPort", Bool::BoolOutputPort::typeid, 0, -1, -1, 88, 50, 25, 100, "Green", true, "")]
	
	public ref class OTE : public DCSLogicComponent
	{
	public:
		
		Rockwell_Library::OTE()
		{
			TypeDescription			= "OTE";
			Name					= "OTE";
			Descriptor				= "Output Energize";

			Input.Visible			= true;
			Input.Value				= false;
			InputPort				= dynamic_cast<Bool::BoolInputPort^>(PortByName("InputPort"));
			InputPort->SetAssociatedProperty(%m_Input);
			
			Output.Visible			= true;
			Output.Value			= Input.Value;
			OutputPort				= dynamic_cast<Bool::BoolOutputPort^>(PortByName("OutputPort"));
			OutputPort->SetAssociatedProperty(%m_Output);
			
			Value.Visible			= true;

			Property.Visible		= true;	
			m_Project = IPS::Server::IProject::GetInstance();
		}

		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Input")]
		[IPS::Properties::GridOrder(0)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"General"})]
		virtual property IPS::Properties::Bool%  Input
		{
			IPS::Properties::Bool%  get()
			{	
				return m_Input;
			}
		}
		
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Output")]
		[IPS::Properties::GridOrder(1)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"General"})]
		virtual property IPS::Properties::Bool%  Output
		{
			IPS::Properties::Bool%  get()
			{
				return m_Output;
			}
		}
		
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Address")]
		[IPS::Properties::GridOrder(100)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Component"})]
		virtual property IPS::Properties::Text%  Property
		{
			IPS::Properties::Text%  get()
			{
				return m_Property;
			}
		}
		
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Value")]
		[IPS::Properties::GridOrder(101)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Component"})]
		virtual property IPS::Properties::Bool%  Value
		{
			IPS::Properties::Bool%  get()
			{
				return m_Value;
			}
		}
		
		//
		// Methods
		//

		virtual System::Void InitProperties() override
		{
			IPS::Plugin::ComponentBase::InitProperties();
		}

		virtual System::Void Execute(double) override;
		
		virtual void SetVisibilities(bool l_bShowInvisibleProperties) override
		{
			DCSLogicComponent::SetVisibilities(l_bShowInvisibleProperties);

			if (l_bShowInvisibleProperties == true)
			{
				Input.Visible				= true;
				Output.Visible				= true;
				Value.Visible				= true;
				Property.Visible			= true;
			}
			else
			{
				Input.Visible				= m_Input.Visible;
				Output.Visible				= m_Output.Visible;
				Value.Visible				= m_Value.Visible;
				Property.Visible			= m_Property.Visible;
			}
		}

	private: 
			
			IPS::Properties::Bool	m_Input;
			IPS::Properties::Bool	m_Output;
			IPS::Properties::Bool	m_Value;
			IPS::Properties::Text	m_Property;
			DCSInputPortBase^		InputPort;
			DCSOutputPortBase^		OutputPort;
	};
}