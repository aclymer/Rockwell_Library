#pragma once
#include "Stdafx.h"
#include "Ports.h"
#include "Rockwell_Library/Components/Hidden/DCSLogicComponent.h"
#include "Rockwell_Library/Components/Hidden/ITimer.h"
#include "Rockwell_Library/Tasks/DCSLogicTaskDrawingTextProvider.h"

using namespace System;
using namespace IPS::Server;
using namespace DCS::Ports;

namespace Rockwell_Library
{	
	[IPS::Plugin::LibraryInfo("TON", IPS::Plugin::Visibility::VISIBLE, "Timer On Delay")]
	[IPS::Plugin::DrawingTextProvider(DCSLogicTaskDrawingTextProvider::typeid)]
	[IPS::Plugin::LibraryImage("TON.png")]
	[IPS::Plugin::LibrarySize(200,125)]
	[IPS::Plugin::LibraryRelativeSizeAttribute(false)]
	[IPS::Plugin::LibraryCategory("Ladder Logic", "Timer and Counter Instructions")]
	[IPS::Plugin::Port("InputPort", Bool::BoolInputPort::typeid, -1, 0, -1, 0, 20, 13, 20, "Green", true, "")]
	[IPS::Plugin::Port("ENPort",	Bool::BoolOutputPort::typeid, 0, -1, -1, 100, 20, 13, 20, "Green", true, "")]
	[IPS::Plugin::Port("DNPort",	Bool::BoolOutputPort::typeid, 0, -1, -1, 100, 50, 13, 20, "Green", true, "")]

	public ref class TON : public DCSLogicComponent, ITimer
	{
	public:

		TON()
		{
			TypeDescription			= "TON";
			Name					= "TON";
			Descriptor				= "Timer On Delay";

			Input.Visible			= true;
			Input.Value				= false;
			InputPort				= dynamic_cast<BoolInputPort^>(PortByName("InputPort"));
			InputPort->SetAssociatedProperty(%m_Input);
			
			EN.Visible				= true;
			EN.Value				= false;
			ENPort					= dynamic_cast<BoolOutputPort^>(PortByName("ENPort"));
			ENPort->SetAssociatedProperty(%m_Enable);
			
			DN.Visible				= true;
			DN.Value				= false;
			DNPort					= dynamic_cast<BoolOutputPort^>(PortByName("DNPort"));
			DNPort->SetAssociatedProperty(%m_Done);

			TT.Visible				= false;
			TT.Value				= false;

			ACC.Visible				= true;
			ACC.Value				= 0;

			Source.Visible			= true;
			Source.Value			= "T0:0";

			Preset.Visible			= true;
			Preset.Value			= 0;
			Preset.SetDisplayUnit(IPS::Units::UnitGroup::Time, IPS::Units::Unit::s);

			Input_Prev.Visible		= false;
			Input_Prev.Value		= false;

			Timebase.Visible		= true;
			Timebase.Value			= 1;
			Timebase.SetDisplayUnit(IPS::Units::UnitGroup::Time, IPS::Units::Unit::s);

			m_Project				= IPS::Server::IProject::GetInstance();
		}
		
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Input")]
		[IPS::Properties::GridOrder(10)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"General"})]
		property IPS::Properties::Bool% Input
		{
			IPS::Properties::Bool% get()
			{
				return m_Input;
			}
		}
		
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Timer")]
		[IPS::Properties::GridOrder(0)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Timer"})]
		property IPS::Properties::Text% Source
		{
			IPS::Properties::Text% get()
			{
				return m_Source;
			}
			void set(IPS::Properties::Text% text)
			{
				m_Source				= text;				
				m_EN_Dest.Value			= m_Source.Value + "/EN";
				m_TT_Dest.Value			= m_Source.Value + "/TT";
				m_DN_Dest.Value			= m_Source.Value + "/DN";
				m_ACC_Dest.Value		= m_Source.Value + ".ACC";
				m_Timebase_Source.Value = m_Source.Value + ".BASE";
				m_Preset_Source.Value	= m_Source.Value + ".PRE";
			}
		}

		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Time Base")]
		[IPS::Properties::GridOrder(10)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Timer"})]
		property IPS::Properties::Double% Timebase
		{
			IPS::Properties::Double% get()
			{
				return m_Timebase;
			}
		}
		
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Preset")]
		[IPS::Properties::GridOrder(20)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Timer"})]
		property IPS::Properties::Double% Preset
		{
			IPS::Properties::Double% get()
			{
				return m_Preset;
			}
		}

		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Accum")]
		[IPS::Properties::GridOrder(30)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Timer"})]
		property IPS::Properties::Double% ACC
		{
			IPS::Properties::Double% get()
			{
				return m_Accumulated;
			}
		}
		
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("EN")]
		[IPS::Properties::GridOrder(0)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Output"})]
		property IPS::Properties::Bool% EN
		{
			IPS::Properties::Bool% get()
			{
				return m_Enable;
			}
			void set(IPS::Properties::Bool% value)
			{
				TON::Set_Property(Source.Value + "/EN", value.Value);
				m_Enable = value;
			}
		}

		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("DN")]
		[IPS::Properties::GridOrder(10)]
			[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Output"})]
		property IPS::Properties::Bool% DN
		{
			IPS::Properties::Bool% get()
			{
				return m_Done;
			}
		}
		
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::RESULT)]
		[IPS::Properties::DisplayName("TT")]
		[IPS::Properties::GridOrder(0)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Internal"})]
		property IPS::Properties::Bool% TT
		{
			IPS::Properties::Bool% get()
			{
				return m_Timing;
			}
		}

		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::RESULT)]
		[IPS::Properties::DisplayName("IN")]
		[IPS::Properties::GridOrder(10)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"Internal"})]
		property IPS::Properties::Bool% Input_Prev
		{
			IPS::Properties::Bool% get()
			{
				return m_Input_Prev;
			}
		}

		void CountUp(double Ts)
		{
			// Increment Counter (sec)
			ACC.Value += Ts / Timebase.Value;
		}
		
		virtual void Step(double Ts) override
		{
			EN.Value = Input.Value;

			if (Input.Value == false)
			{
				ACC.Value		= 0;
				TT.Value		= false;
				DN.Value		= false;
			}
			else
				TT.Value		= true;

			if (Input.Value == true && ACC.Value < Preset.Value)
			{
				CountUp(Ts);
				if (ACC.Value >= Preset.Value)
				{
					TT.Value	= false;
					DN.Value	= true;
				}
			}

			Input_Prev.Value	= Input.Value;

			Execute(Ts);
		}
		
		virtual System::Void InitProperties() override
		{
			IPS::Plugin::ComponentBase::InitProperties();
		}

		virtual System::Void Execute(double) override;

		virtual void SetVisibilities(bool l_bShowInvisibleProperties) override
		{
			DCSLogicComponent::SetVisibilities(l_bShowInvisibleProperties);

			if (l_bShowInvisibleProperties == true)
			{
				Input.Visible			= true;
				EN.Visible				= true;
				DN.Visible				= true;
				ACC.Visible				= true;
				TT.Visible				= true;
				Source.Visible			= true;
				Input_Prev.Visible		= true;
				Preset.Visible			= true;
				Timebase.Visible		= true;
			}
			else
			{
				Input.Visible			= m_Input.Visible;
				EN.Visible				= m_Enable.Visible;
				DN.Visible				= m_Done.Visible;
				ACC.Visible				= m_Accumulated.Visible;
				TT.Visible				= m_Timing.Visible;
				Source.Visible			= m_Source.Visible;
				Input_Prev.Visible		= m_Input.Visible;
				Preset.Visible			= m_Preset.Visible;
				Timebase.Visible		= m_Timebase.Visible;
			}
		}

	private:
		
		IPS::Properties::Bool		m_Input;
		IPS::Properties::Bool		m_Enable;
		IPS::Properties::Bool		m_Done;
		IPS::Properties::Double		m_Accumulated;
		IPS::Properties::Bool		m_Timing;
		IPS::Properties::Text		m_Source;
		IPS::Properties::Text		m_EN_Dest;
		IPS::Properties::Text		m_TT_Dest;
		IPS::Properties::Text		m_DN_Dest;
		IPS::Properties::Text		m_ACC_Dest;
		IPS::Properties::Text		m_Timebase_Source;
		IPS::Properties::Text		m_Preset_Source;
		IPS::Properties::Bool		m_Input_Prev;
		IPS::Properties::Double		m_Preset;
		IPS::Properties::Double		m_Timebase;
		DCSInputPortBase^			InputPort;
		DCSOutputPortBase^			ENPort;
		DCSOutputPortBase^			DNPort;
	};
}