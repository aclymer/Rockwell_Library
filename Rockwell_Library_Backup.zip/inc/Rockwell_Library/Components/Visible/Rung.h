#pragma once
#include "Ports.h"
#include "Rockwell_Library/Components/Hidden/DCSLogicComponent.h"
#include "Rockwell_Library/Tasks/DCSLogicTask.h"
#include "Rockwell_Library/Tasks/DCSLogicTaskDrawingTextProvider.h"

using namespace System;
using namespace IPS::Server;
using namespace DCS::Ports;

namespace Rockwell_Library
{
	[IPS::Plugin::LibraryInfo("Rung", IPS::Plugin::Visibility::VISIBLE, "Start Of Rung")]
	[IPS::Plugin::DrawingTextProvider(DCSLogicTaskDrawingTextProvider::typeid)]
	[IPS::Plugin::LibraryImage("Rung.png")]
	[IPS::Plugin::LibrarySize(100,50)]
	[IPS::Plugin::LibraryCategory("Ladder Logic")]
	[IPS::Plugin::Port("RungPort", Bool::BoolOutputPort::typeid, 0, -1, -1, 100, 50, 25, 100, "Green", true, "")]

	public ref class Rung : public DCSLogicComponent
	{
	public:

		Rockwell_Library::Rung()
		{

			TypeDescription				= "Rung";
			Name						= "Rung";
			Descriptor					= "Rung";

			Energize.Visible			= true;
			Energize.Value				= false;
			RungPort					= dynamic_cast<Bool::BoolOutputPort^>(PortByName("RungPort"));
			RungPort->SetAssociatedProperty(%m_Energize);
		}

		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("Energize")]
		[IPS::Properties::GridOrder(0)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"General"})]
		virtual property IPS::Properties::Bool% Energize
		{			
			IPS::Properties::Bool% get()
			{
				return m_Energize;
			}
		}

		virtual System::Void InitProperties() override
		{
			IPS::Plugin::ComponentBase::InitProperties();
		}

		virtual System::Void Execute(double) override;

		virtual void SetVisibilities(bool l_bShowInvisibleProperties) override
		{
			DCSLogicComponent::SetVisibilities(l_bShowInvisibleProperties);

			if (l_bShowInvisibleProperties == true)
				Energize.Visible			= true;
			else
				Energize.Visible			= m_Energize.Visible;
		}

	private:
		
		IPS::Properties::Bool	m_Energize;
		DCSOutputPortBase^		RungPort;
	};
}