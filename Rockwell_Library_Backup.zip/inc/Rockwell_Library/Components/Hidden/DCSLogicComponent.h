#pragma once
#include "Ports.h"
#include "Stdafx.h"
#include "Rockwell_Library/Properties/CompoundProperty.h"
#include "Rockwell_Library/Properties/CompoundStringProperty.h"

using namespace System;
using namespace System::Reflection;
using namespace System::Collections::Generic;
using namespace System::Text::RegularExpressions;
using namespace DCS::Ports::Bool;

namespace Rockwell_Library {

	ref class MetaDataEditor;
	
	[IPS::Plugin::LibraryInfo("Rockwell Logic Component Base", IPS::Plugin::Visibility::HIDDEN, "Rockwell Logic Component Base")]
	public ref class DCSLogicComponent : public DCS::Components::DCSComponentBase
	{
	public:

		DCSLogicComponent()
		{
			//
			// General
			//

			m_ShowInvisibleProperties.Value = false;
			l_Subroutine					= "U:2";
			
			//
			// Config
			//
			
			//
			// Inputs
			//

			//
			// Outputs
			//
			
		}

	public:
		
		virtual System::Object^ Get_Property(String^ source)
		{
			try
			{
				return m_Project->GetComponent(source)->GetPropertyFromPropID("Value")->ValueAsObject;
			}
			catch(System::Exception^ e)
			{
				System::Double^ Value = gcnew System::Double(0);
				if (System::Double::TryParse(source, *Value) == false)
					IPS::Errors::ErrorSystem::Report(gcnew IPS::Errors::ElementError(e->Message, this->Identifier, "Invalid Identifier: " + source));
				return Value;
			}
		}
		
		virtual System::Void Set_Property(String^ destination, System::Object^ object)
		{
			try
			{
				m_Project->GetComponent(destination)->GetPropertyFromPropID("Value")->ValueAsObject = object;
			}
			catch(System::Exception^ e)
			{
				IPS::Errors::ErrorSystem::Report(gcnew IPS::Errors::ElementError(e->Message, this->Identifier, "Invalid Identifier: " + destination));
			}
		}

		virtual void InitProperties() override
		{
			IPS::Plugin::ComponentBase::InitProperties();		
		}

		void InitialiseVisibilities()
		{
			m_ShowInvisibleProperties.ValueChanged += gcnew EventHandler(this, &DCSLogicComponent::SetVisibilities);
		}

		virtual void SetVisibilities(bool l_bShowInvisibleProperties)
		{
		}
		
		void SetVisibilities(Object^ p_pSender, EventArgs^ p_pEventArgs)
		{			
			SetVisibilities(m_ShowInvisibleProperties.Value);
		}

		void ParseAddress(List<String^>% parsed, String^ address)
		{
			parsed.Clear();
			try
			{
				Regex^ re = gcnew Regex("(#)?([A-Z]{1,2})((?:\\d+){0,3}?):([0-9]+)([./])?([\\dA-Z])?");
				if (re->IsMatch(address))
					parsed.AddRange(re->Split(address));
			}
			catch (System::Exception^ e)
			{
				Console::WriteLine("Syntax error in the regular expression. (%s)", e->Message);
			}
		}

		//
		// General
		//

		[IPS::Persistence::DoNotPersist]
		[IPS::Properties::PropertyUsage(IPS::Properties::UseProperty::DYNAMIC)]
		[IPS::Properties::DisplayName("ShowInvisibleProperties")]
		[IPS::Properties::GridOrder(0x90000)]
		[IPS::Properties::GridCategory(gcnew cli::array< System::String^  >(1) {"General"})]
		property IPS::Properties::Bool% ShowInvisibleProperties
		{
			IPS::Properties::Bool% get()
			{
				return m_ShowInvisibleProperties;
			}
		}

		//
		// Methods
		//

		virtual void InitScales()
		{
		}
		
		virtual void ReadInputs() override
		{
			DCS::Components::DCSComponentBase::ReadInputs();
			
			for each (IPS::Core::Port^ l_Port in this->Ports)
			{
				l_BoolInputPort = dynamic_cast<BoolInputPort^>(l_Port);
				if (l_BoolInputPort != nullptr)
				{
					if (l_BoolInputPort->IsConnected == false)			
						l_BoolInputPort->AssociatedProperty->ValueAsObject = false;
					else
					{
						l_Value.Value = false;
						for each (IPS::Core::Link^ l_Link in l_BoolInputPort->Links)
						{
							if (l_Link->StartPort != nullptr)
							{								
								BoolOutputPort^ r_BoolOutputPort = dynamic_cast<BoolOutputPort^>(l_Link->StartPort);
								if (r_BoolOutputPort != nullptr)
									l_Value.Value |= (bool) r_BoolOutputPort->AssociatedProperty->ValueAsObject;
							}
						}
					
						l_BoolInputPort->AssociatedProperty->ValueAsObject = l_Value.Value;
					}
				}

			}
		}
		
		virtual void Activate_Compound()
		{
		}
		
		virtual void Execute(double p_dTimeStep)
		{
		}

		virtual System::Void Step(System::Double dDt) override
		{
			Execute(dDt);
		}

	public:

		IPS::Core::Page^		m_CurrentPage;
		IPS::Properties::Bool	m_ShowInvisibleProperties;
		IPS::Server::IProject^	m_Project;

		String^					TypeDescription;
		String^					Name;
		String^					Descriptor;
		String^					l_Subroutine;

	private:
		
		static IPS::Properties::Bool	l_Value;
		static BoolInputPort^			l_BoolInputPort;
		static BoolOutputPort^			r_BoolOutputPort;

		void InitCompoundProperties()
		{
			Type^ l_pType = this->GetType();
			List<PropertyInfo^>^ l_pCompoundProperties;
			if (CompoundProperties.TryGetValue(l_pType, l_pCompoundProperties) == false)
			{
				l_pCompoundProperties = gcnew List<PropertyInfo^>();
				for each (PropertyInfo^ l_pPropertyInfo in this->GetType()->GetProperties())
				{
					if (l_pPropertyInfo->PropertyType->IsSubclassOf(CompoundProperty::typeid) == true)
					{
						l_pCompoundProperties->Add(l_pPropertyInfo);
					}
				}
				CompoundProperties.Add(l_pType, l_pCompoundProperties);
			}
		}

		static Dictionary<Type^,List<PropertyInfo^>^> CompoundProperties;
	};
	
}