#pragma once
#include "Stdafx.h"

using namespace System;
using namespace System::Collections;
using namespace DCS::Task;

namespace Rockwell_Library
{
	public ref class ControlTask : public DistributedControlTask
	{
		ref class DistributedControlTask;

		ControlTask()
		{
			DiagnosticMode.Value = true;
		}

	public:

		virtual property IPS::Properties::Bool% DiagnosticMode
		{
			IPS::Properties::Bool% get() override
			{
				return this->DiagnosticMode;
			}
		}


	};
}