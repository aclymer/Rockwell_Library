#pragma once
using namespace System;
using namespace System::Windows::Forms;

namespace Rockwell_Library {

	public ref class DCSLogicTaskDrawingTextProvider : IPS::Plugin::DrawingTextProvider
	{

	public: 

		DCSLogicTaskDrawingTextProvider();

		virtual void GetDrawingText(Object^ objectToProvideMenuFor, System::Collections::Generic::List<IPS::Plugin::DrawingText>^ returnDrawingTexts);

		property Object^ Context
		{
			virtual void set(Object^ newValue)
			{
			}
		}
	};

}